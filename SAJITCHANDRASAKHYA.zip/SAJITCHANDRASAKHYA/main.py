import random
from docx import Document

# Open the Word file
document = Document('questions.docx')

# Prompt the user to specify the format of the questions
question_format = input("Are the questions in table cells, separate paragraphs, or not numbered? (Enter 'table', 'paragraph', or 'not numbered'):  ")

# Initialize an empty list to store the questions
questions = []

if question_format == "table":
    # Iterate over the tables in the document
    for table in document.tables:
        # Iterate over the rows in the table
        for row in table.rows:
            # Iterate over the cells in the row
            for cell in row.cells:
                # Add the text of the cell to the questions list
                questions.append(cell.text)
elif question_format == "paragraph":
    # Iterate over the paragraphs in the document
    for para in document.paragraphs:
        # Add the text of the paragraph to the questions list
        questions.append(para.text)
else:
    # Iterate over the paragraphs in the document
    for para in document.paragraphs:
        # Add the text of the paragraph to the questions list
        questions.append(para.text)

num_questions = int(input("Enter the number of questions you want to be printed in random: "))

# Function to select a specified number of random questions
def select_random_questions():
    selected_questions = random.sample(questions, num_questions)
    return selected_questions

# Example usage: select 5 random questions
my_selected_questions = select_random_questions()

# Creating a new docx file
document = Document()
for i, question in enumerate(my_selected_questions, 1):
    document.add_paragraph(f"{i}. {question}")

document.save("random.docx")

print("Randomly selected questions saved to random.docx.")